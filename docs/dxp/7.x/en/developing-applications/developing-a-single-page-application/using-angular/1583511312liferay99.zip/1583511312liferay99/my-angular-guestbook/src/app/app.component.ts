import { Component } from '@angular/core';
//import {ViewGuestbookComponent} from './view-guestbook/view-guestbook.component'

@Component({
	templateUrl: '/o/my-angular-guestbook/app/app.component.html'
})
export class AppComponent {
	
	title = 'Guestbook';

}
