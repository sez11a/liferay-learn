export class GuestbookEntry {
  id: number;
  name: string;
  message: string;
}